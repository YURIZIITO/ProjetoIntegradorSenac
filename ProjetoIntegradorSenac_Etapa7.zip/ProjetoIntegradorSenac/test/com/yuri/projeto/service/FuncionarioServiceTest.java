package com.yuri.projeto.service;

import com.yuri.projeto.model.Funcionario;
import org.junit.Test;
import static org.junit.Assert.*;

public class FuncionarioServiceTest {

    @Test
    public void testCalcularBonus() {
        // Cenário: O código principal usa o salário de 3500
        Funcionario f = new Funcionario("Yuri", 3500.0);
        FuncionarioService service = new FuncionarioService();
        
        // Execução
        double resultado = service.calcularBonus(f);
        
        // Verificação: 10% de 3500 tem que ser 350
        assertEquals(350.0, resultado, 0.01);
    }

    @Test
    public void testValidarSalario() {
        FuncionarioService service = new FuncionarioService();
        boolean resultado = service.validarSalario(100.0);
        assertTrue(resultado);
    }
}
 
 
 
public class FuncionarioServiceTest {
    
    public FuncionarioServiceTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calcularBonus method, of class FuncionarioService.
     */
    @Test
    public void testCalcularBonus() {
        System.out.println("calcularBonus");
        Funcionario f = null;
        FuncionarioService instance = new FuncionarioService();
        double expResult = 0.0;
        double result = instance.calcularBonus(f);
        assertEquals(expResult, result, 0);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validarSalario method, of class FuncionarioService.
     */
    @Test
    public void testValidarSalario() {
        System.out.println("validarSalario");
        double salario = 0.0;
        FuncionarioService instance = new FuncionarioService();
        boolean expResult = false;
        boolean result = instance.validarSalario(salario);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
