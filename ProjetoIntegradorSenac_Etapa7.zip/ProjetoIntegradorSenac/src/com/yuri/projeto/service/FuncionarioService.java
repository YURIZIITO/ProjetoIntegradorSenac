package com.yuri.projeto.service;

import com.yuri.projeto.model.Funcionario;

public class FuncionarioService {
    
    public double calcularBonus(Funcionario f) {
        return f.getSalario() * 0.10;
    }

    public boolean validarSalario(double salario) {
        return salario > 0;
    }
}