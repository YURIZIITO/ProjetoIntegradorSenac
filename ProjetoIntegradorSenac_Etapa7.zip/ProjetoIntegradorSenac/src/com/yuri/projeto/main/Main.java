package com.yuri.projeto.main;

import com.yuri.projeto.model.Funcionario;
import com.yuri.projeto.service.FuncionarioService;

public class Main {
    public static void main(String[] args) {
        Funcionario func = new Funcionario("Yuri", 3500.0);
        
        FuncionarioService service = new FuncionarioService();
        
        if (service.validarSalario(func.getSalario())) {
            double bonus = service.calcularBonus(func);
            
            System.out.println("--- RELATORIO DE FUNCIONARIO ---");
            System.out.println("Nome: " + func.getNome());
            System.out.println("Salario Base: R$ " + func.getSalario());
            System.out.println("Bonus Calculado (10%): R$ " + bonus);
            System.out.println("---------------------------------");
            System.out.println("SISTEMA PRONTO PARA WEB: SUCESSO!");
        } else {
            System.out.println("Erro: Salário inválido!");
        }
    }
}