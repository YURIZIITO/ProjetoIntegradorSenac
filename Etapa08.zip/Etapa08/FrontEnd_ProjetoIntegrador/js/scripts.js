document.getElementById('formFuncionario')?.addEventListener('submit', function(event) {
    event.preventDefault(); 
    const nome = document.getElementById('nome').value;
    const salario = parseFloat(document.getElementById('salario').value);
    const mensagem = document.getElementById('mensagem');

    if (nome.length < 3) {
        mensagem.innerText = "O nome deve ter pelo menos 3 caracteres.";
        return;
    }

    if (salario <= 0) {
        mensagem.innerText = "O salário deve ser maior que zero!";
        return;
    }

    alert("Funcionário " + nome + " validado com sucesso (Front-end)!");
    mensagem.innerText = "";
    window.location.href = "index.html"; 
});